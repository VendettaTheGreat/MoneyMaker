const puppeteer = require('puppeteer');
const axios = require('axios');
const wait = ms => new Promise(res => setTimeout(res, ms));
const SocksProxyAgent = require('socks-proxy-agent');
const crypto = require("crypto");
const proxyChain = require("proxy-chain");
var fs = require('fs');
var log = fs.createWriteStream("log.txt", {flags:'a'});
var settings = JSON.parse(fs.readFileSync('settings.json'));
var Browsers = [];
var {adfocus_apikeys, maxthreads, proxy_Timeout, navigation_Timeout, shuffle_Proxies, custom_Proxies, use_customproxies, max_instances, mix_custom, reuse_link, reuse_times, try_timeout, slowdown} = settings;
var cache = {};
var saved_requests = 0;
var saved_size = 0;


process.on('uncaughtException', err => {
    log.write(err+"\n");
});

process.on('unhandledRejection',err=>{
    log.write(err+"\n");
});

function getGUID(){
    return crypto.randomBytes(4).toString("hex")+"-"+crypto.randomBytes(4).toString("hex")+"-"+crypto.randomBytes(4).toString("hex")+"-"+crypto.randomBytes(4).toString("hex");
}

function shuffle(array) {
  let currentIndex = array.length,  randomIndex;
  while (currentIndex != 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }
  return array;
}

async function getHastebin(){
    return "https://www.toptal.com/developers/hastebin/"+(await axios.post('https://www.toptal.com/developers/hastebin/documents',getGUID())).data.key
}

function hash(str){
    return crypto.createHash('md5').update(str).digest("hex");
}

async function enableCache(page){
    await page.setRequestInterception(true);
    await page.setCacheEnabled(false)
    page.on('request',request=>{
        if(cache[hash(request.url())]){
            request.respond(cache[hash(request.url())]);
            saved_size += cache[hash(request.url())].body.length;
            saved_requests++;
        }else{
        request.continue();
    }
    });
    page.on('response',async response=>{
        if(response.request().resourceType()!="script"&&response.request().resourceType()!="stylesheet"&&response.request().resourceType()!="image"||response.request().isNavigationRequest()||cache[hash(response.url())])return;
        try{
            cache[hash(response.url())] = {
              status:response.status(),
              headers:response.headers(),
              contentType:response.headers()['content-type'],
              body:await response.buffer()
            }
        }catch(e){}
    })
}

async function getLocal(proxy){
    var [protocol,host,port,username,password] = proxy.split(":");
    var _proxy = await proxyChain.anonymizeProxy(protocol+"://"+username+":"+password+"@"+host+":"+port);
    var formattedProxy = _proxy.match(/(\d+\.\d+\.\d+\.\d+):(\d+)/i);
    return {proxy:{host:formattedProxy[1],port:formattedProxy[2]},close:async ()=>{await proxyChain.closeAnonymizedProxy(_proxy,true)}};
}

async function checkProxy(proxy){
    var [protocol,host,port,username,password] = proxy.split(":");
    if(username&&password){
        var handlerProxy = getLocal(proxy);
        protocol = "http";
        host = handlerProxy.proxy.host;
        port = handlerProxy.proxy.port;
    }
    function end(){
        if(!handlerProxy)return;
        handlerProxy.close();
    }
    proxy = host+":"+port;
    if(protocol=="socks"||protocol == "socks4"||protocol=="socks5"){
        try{
            var httpsAgent = new SocksProxyAgent(protocol+'://'+proxy);
            var result = await axios.request({
                url:'https://api.ipify.org/',
                timeout:proxy_Timeout,
                method:'get',
                httpsAgent
            });
            end();
            return true; 
        }catch(e){end();return false}
    }else if(protocol=="https"||protocol=="http"){
        try{
            var result = await axios.request({
                url:'https://api.ipify.org/',
                timeout:proxy_Timeout,
                method:'get',
                proxy: {protocol,host,port}
            });
            end();
            return true; 
        }catch(e){end();return false}
    }
    end();
    return false;
}

async function getIP(){
    return (await axios.get('https://api.ipify.org/')).data;
}

async function filterProxies(args={}){
    var {limit,onWorking,checkInstances} = args;
    var sources = [
    {protocol:'http',url:'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all'},
    {protocol:'socks4',url:'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=10000&country=all'},
    {protocol:'socks5',url:'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all'},
    {protocol:'http',custom:async ()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://free-proxy-list.net/',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
            var le = document.querySelector('[class="table table-striped table-bordered"]').children[1].children;
            var proxies = [];
            for(var i = 0;i<le.length;i++){
                var data = le[i].children;
                proxies[proxies.length] = data[0].innerHTML+":"+data[1].innerHTML;
            }
            return proxies.join("\n");
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://premiumproxy.net/full-proxy-list',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
            var data = document.querySelector('body > center:nth-child(1) > div:nth-child(17) > table:nth-child(1) > tbody:nth-child(3)').children;
            var proxies = [];
            for(var i = 0;i<data.length;i++){
                try{proxies[proxies.length] = data[i].children[0].children[0].innerText}catch(e){}
            }
            return proxies.join("\n")
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'socks5',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://proxypremium.top/full-proxy-list',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
            var data = document.querySelector('body > center:nth-child(1) > div:nth-child(17) > table:nth-child(1) > tbody:nth-child(3)').children;
            var proxies = [];
            for(var i = 0;i<data.length;i++){
              try{proxies[proxies.length]=data[i].children[0].innerText}catch(e){}
            }
            return proxies.join("\n")
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        var totalProxies = [];
        for(var i = 1;i<12;i++){
            try{
                await page.goto('https://premproxy.com/list/ip-port/'+i+'.htm',{waitUntil:'networkidle2'});
                totalProxies[totalProxies.length] = await page.evaluate(async()=>{
                    var data = document.getElementById('ipportlist').children;
                    var proxies = [];
                    for(var i = 0;i<data.length;i++){
                        try{proxies[proxies.length] = data[i].innerText}catch(e){}
                    }
                    return proxies.join('\n');
                })
            }catch(e){}
        }
        try{browser.close()}catch(e){}
        return totalProxies.join("\n");
    }},
    {protocol:'socks5',custom:async()=>{
        var result = await axios.request({
            url:'https://hidester.com/proxydata/php/data.php?mykey=data&offset=0&limit=5000&orderBy=latest_check&sortOrder=DESC&country=&port=&type=8&anonymity=7&ping=7&gproxy=2',
            method:'get',
            headers: {'Referer': 'https://hidester.com/proxylist/'}
          });
        var proxies = [];
        for(var i = 0;i<result.data.length;i++){
            proxies[proxies.length] = result.data[i].IP+':'+result.data[i].PORT;
        }
        return proxies.join("\n");
    }},
    {protocol:'socks4',custom:async()=>{
        var result = await axios.request({
            url:'https://hidester.com/proxydata/php/data.php?mykey=data&offset=0&limit=50&orderBy=latest_check&sortOrder=DESC&country=&port=&type=4&anonymity=7&ping=7&gproxy=2',
            method:'get',
            headers: {'Referer': 'https://hidester.com/proxylist/'}
          });
        var proxies = [];
        for(var i = 0;i<result.data.length;i++){
            proxies[proxies.length] = result.data[i].IP+':'+result.data[i].PORT;
        }
        return proxies.join("\n");
    }},
    {protocol:'http',custom:async()=>{
        var result = await axios.request({
            url:'https://hidester.com/proxydata/php/data.php?mykey=data&offset=0&limit=50&orderBy=latest_check&sortOrder=DESC&country=&port=&type=1&anonymity=7&ping=7&gproxy=2',
            method:'get',
            headers: {'Referer': 'https://hidester.com/proxylist/'}
          });
        var proxies = [];
        for(var i = 0;i<result.data.length;i++){
            proxies[proxies.length] = result.data[i].IP+':'+result.data[i].PORT;
        }
        return proxies.join("\n");
    }},
    {protocol:'socks5',url:'https://raw.githubusercontent.com/RealStar0/proxies/main/socks'},
    {protocol:'http',url:'https://raw.githubusercontent.com/RealStar0/proxies/main/http'},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://spys.one/en/free-proxy-list/',{waitUntil:'networkidle2'});
        await page.select('#xf5','1');
        await page.waitForSelector('#xf5');
        var proxies = await page.evaluate(async()=>{
            var proxies = [];
            var data = document.querySelector('body > table:nth-child(3) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(1) > table:nth-child(1) > tbody:nth-child(1)').children;
            for(var i = 2;i<data.length-1;i++){
            proxies[proxies.length] = data[i].children[0].innerText;
            }
            return proxies.join("\n")
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'socks5',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://spys.one/en/free-proxy-list/',{waitUntil:'networkidle2'});
        await page.select('#xf5','2');
        await page.waitForSelector('#xf5');
        var proxies = await page.evaluate(async()=>{
            var proxies = [];
            var data = document.querySelector('body > table:nth-child(3) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(1) > table:nth-child(1) > tbody:nth-child(1)').children;
            for(var i = 2;i<data.length-1;i++){
            proxies[proxies.length] = data[i].children[0].innerText;
            }
            return proxies.join("\n")
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://www.proxynova.com/proxy-server-list/',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
            var data = document.querySelector('#tbl_proxy_list > tbody:nth-child(2)').children;
            var proxies = [];
            for(var i = 0;i<data.length;i++){
                if(data[i].children[0].innerText!=""){
                proxies[proxies.length] = data[i].children[0].innerText;
                }
            }
            return proxies.join('\n');
        })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        var totalProxies = [];
        for(var i = 1;i<3;i++){
            try{
                await page.goto('https://www.freeproxylists.net/?pr=HTTP&u=50&page='+i,{waitUntil:'networkidle2'});
                totalProxies[totalProxies.length] = await page.evaluate(async()=>{
                    var data = document.querySelector('.DataGrid > tbody:nth-child(1)').children;
                    var proxies = [];
                    for(var i = 1;i<data.length;i++){
                        if(data[i].children[0].innerText!=""){
                        proxies[proxies.length] = data[i].children[0].innerText;
                    }
                    }
                    return proxies.join("\n")
                })
            }catch(e){}
        }
        try{browser.close()}catch(e){}
        return totalProxies.join("\n");
    }},
    {protocol:'https',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        var totalProxies = [];
        for(var i = 1;i<3;i++){
            try{
                await page.goto('https://www.freeproxylists.net/?pr=HTTPS&u=50&page='+i,{waitUntil:'networkidle2'});
                totalProxies[totalProxies.length] = await page.evaluate(async()=>{
                    var data = document.querySelector('.DataGrid > tbody:nth-child(1)').children;
                    var proxies = [];
                    for(var i = 1;i<data.length;i++){
                        if(data[i].children[0].innerText!=""){
                        proxies[proxies.length] = data[i].children[0].innerText;
                    }
                    }
                    return proxies.join("\n")
                })
            }catch(e){}
        }
        try{browser.close()}catch(e){}
        return totalProxies.join("\n");
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://www.proxy-list.download/HTTP',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
                var data = document.querySelector('#tabli').children;
                var proxies = [];
                for(var i = 0;i<data.length;i++){
                    proxies[proxies.length] = data[i].children[0].innerText + ":"+ data[i].children[1].innerText
                }
                return proxies.join("\n")
            })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'https',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://www.proxy-list.download/HTTPS',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
                var data = document.querySelector('#tabli').children;
                var proxies = [];
                for(var i = 0;i<data.length;i++){
                    proxies[proxies.length] = data[i].children[0].innerText + ":"+ data[i].children[1].innerText
                }
                return proxies.join("\n")
            })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'socks4',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://www.proxy-list.download/SOCKS4',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
                var data = document.querySelector('#tabli').children;
                var proxies = [];
                for(var i = 0;i<data.length;i++){
                    proxies[proxies.length] = data[i].children[0].innerText + ":"+ data[i].children[1].innerText
                }
                return proxies.join("\n")
            })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'socks5',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://www.proxy-list.download/SOCKS5',{waitUntil:'networkidle2'});
        var proxies = await page.evaluate(async()=>{
                var data = document.querySelector('#tabli').children;
                var proxies = [];
                for(var i = 0;i<data.length;i++){
                    proxies[proxies.length] = data[i].children[0].innerText + ":"+ data[i].children[1].innerText
                }
                return proxies.join("\n")
            })
        try{browser.close()}catch(e){}
        return proxies;
    }},
    {protocol:'socks5',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://openproxy.space/list',{waitUntil:'networkidle2'});
        var links = await page.evaluate(async()=>{
                return [document.querySelector('.lists').children[0].href,document.querySelector('.lists').children[1].href,document.querySelector('.lists').children[2].href];
            })
        await page.goto(links[0],{waitUntil:'networkidle2'});
        proxies[proxies.length] = await page.evaluate(async()=>{
                return document.querySelector('.data > textarea:nth-child(1)').innerHTML;
            })
        try{browser.close()}catch(e){}
        return proxies.join("\n");
    }},
    {protocol:'socks4',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://openproxy.space/list',{waitUntil:'networkidle2'});
        var links = await page.evaluate(async()=>{
                return [document.querySelector('.lists').children[0].href,document.querySelector('.lists').children[1].href,document.querySelector('.lists').children[2].href];
            })
        await page.goto(links[1],{waitUntil:'networkidle2'});
        proxies[proxies.length] = await page.evaluate(async()=>{
                return document.querySelector('.data > textarea:nth-child(1)').innerHTML;
            })
        try{browser.close()}catch(e){}
        return proxies.join("\n");
    }},
    {protocol:'http',custom:async()=>{
        var browser = await openBrowser();
        var page = (await browser.pages())[0];
        await page.goto('https://openproxy.space/list',{waitUntil:'networkidle2'});
        var links = await page.evaluate(async()=>{
                return [document.querySelector('.lists').children[0].href,document.querySelector('.lists').children[1].href,document.querySelector('.lists').children[2].href];
            })
        await page.goto(links[2],{waitUntil:'networkidle2'});
        proxies[proxies.length] = await page.evaluate(async()=>{
                return document.querySelector('.data > textarea:nth-child(1)').innerHTML;
            })
        try{browser.close()}catch(e){}
        return proxies.join("\n");
    }}
    ];
    var proxies = [];
    var threads = 0;
    var next = 0;
    var filteredProxies = [];
    var formattedSources = [];
    if(use_customproxies){
        console.log(`Using custom proxies [${custom_Proxies.length}]`);
        for(var i = 0;i<custom_Proxies.length;i++){
            var [protocol,url,proxy_login] = custom_Proxies[i].split("---");
            formattedSources[formattedSources.length] = {protocol,url,proxy_login};
        }
        if(mix_custom){            
            sources = sources.concat(formattedSources);
            console.log(`Mixing custom proxies with public proxies [${sources.length}]`);
        }else{
            sources = formattedSources;
        }
    }else{console.log(`Using public proxies[${sources.length}]`)}
    for(var i = 0;i<sources.length;i++){
        try{
            var pre_proxies = (sources[i].custom&&await sources[i].custom()||(await axios.get(sources[i].url)).data).split("\n");
            for(var v = 0;v<pre_proxies.length;v++){
                pre_proxies[v]=sources[i].protocol+":"+pre_proxies[v]+(sources[i].proxy_login&&":"+sources[i].proxy_login||"");
            }
            console.log(`Gathering proxies from source [${i+1}] with new [${pre_proxies.length}] proxies!`);
            proxies = proxies.concat(pre_proxies);
        }catch(e){}
    }

    if(shuffle_Proxies){proxies = shuffle(proxies);console.log("Proxies mixed")}

    async function checkNext(){
        if(next+1>proxies.length||threads>maxthreads)return;
        threads++;
        while(checkInstances()>max_instances-1){await wait(1000)};
        if(next+1>proxies.length||threads>maxthreads)return threads--;
        var localNext = next++;
        var localProxy = proxies[localNext];
        var working = await checkProxy(localProxy);
        if(working){
            try{
                var browser = await openBrowser(localProxy);
                var page = (await browser.pages())[0];
                await enableCache(page);
                await page.goto('https://www.youtube.com/redirect?q=https://google.com',{waitUntil:'networkidle2',timeout:navigation_Timeout});
                if(await page.$('[id=invalid-token-redirect-goto-site-button]')){
                    filteredProxies[filteredProxies.length] = localProxy;
                    if(onWorking)onWorking(localProxy);
                }
            }catch(e){}
            try{
                await browser.close();
            }catch(e){}
        }
        threads--;
        checkNext();
    }

    for(var i = 0;i<maxthreads;i++){
        checkNext();
    }

    while(threads!=0){
        if(limit&&filteredProxies.length>limit-1){
            maxthreads = 0;
        }
        await wait(5000);
        console.log("=========\nInstances: "+checkInstances()+"\nThreads ["+((checkInstances()>max_instances-1)&&"Inactive"||"Active")+"]: "+threads+"\nWorking: "+filteredProxies.length+"\nNext: "+next+"/"+proxies.length+"\n=========");
    }

    return filteredProxies;
}

async function openBrowser(proxy=""){
    var [protocol,host,port,username,password] = proxy.split(":");
    if(username&&password){
        var handlerProxy = getLocal(proxy);
        protocol = "http";
        host = handlerProxy.proxy.host;
        port = handlerProxy.proxy.port;
    }
    try{
        var Browser = await puppeteer.launch({args:['--no-sandbox',protocol&&`--proxy-server=${protocol}://${host}:${port}`||'']});
        Browsers[Browsers.length] = Browser;
        if(handlerProxy){
            Browser.on('targetdestroyed',target=>{
                if(target.type()=="browser"){
                    handlerProxy.close();
                }
            })
        }
        return Browser;
    }catch(e){
        if(handlerProxy){
            handlerProxy.close();
        }
        return false;
    }
}


async function visit(link, proxy, instance){
    var end;
    var hasEnded = false;
    instance.cancel = function(){
        end();
    }

    instance.hasFinished = function(){
        return hasEnded;
    }

    var browser = await openBrowser(proxy);
    if(!browser)return [false,"Browser"];
    var page = (await browser.pages())[0];
    await enableCache(page);
    async function end(){
        try{
            hasEnded = true;
            await browser.close();
        }catch(e){}
    }

    try{
        await page.goto('https://www.youtube.com/redirect?q='+link,{waitUntil:'networkidle2',timeout:navigation_Timeout});
    }catch(e){
        end();
        return [false,"Timeout"];
    }
    var nextButton = await page.$('[id=invalid-token-redirect-goto-site-button]');
    if(!nextButton){
        end();
        return [false,"Button not found"];
    }
    try{
        nextButton.click();
    }catch(e){
        end();
        return [false,"Error while clicking"];
    }
    try{
        await page.waitForSelector('#showSkip',{timeout:navigation_Timeout});
    }catch(e){
        end();
        return [false,"Timeout Skip"]
    }
    try{
        await page.mouse.move(0, 0);
        await page.mouse.down();
        await page.mouse.move(0, 100);
        await page.mouse.move(100, 100);
        await page.mouse.move(100, 0);
        await page.mouse.move(0, 0);
        await page.mouse.up();
    }catch(e){}
    await page.evaluate(async nav=>{
        var loop = 0;
        var delay = ms => new Promise(res => setTimeout(res, ms));
        while(document.querySelector('#showSkip').style.display=="none"){
          await delay(100);
          loop++;if(loop>(nav/100))break;
        }
        document.querySelector('.skip').click();
    },navigation_Timeout)
    try{
        await page.waitForSelector('#box',{timeout:3000});
    }catch(e){
        end();
        return [true,"Timeout Hastebin"];
    }
    end();
    return [true,"None"];
};

getIP().then(ip=>{console.log(`Colab IP: ${ip}`)});

(async()=>{
    //Everything else
    var repeat_url = 0;
    var torepeat_url = [];
    while(true){
        var urls = [];
        var instances = 0;
        if(reuse_link&&repeat_url++<reuse_times&&torepeat_url.length>0){
            urls = torepeat_url;
        }else{
            if(repeat_url++>reuse_times){repeat_url = 0}
            for(var i = 0;i<adfocus_apikeys.length;i++){
                var url = (await axios.get('http://adfoc.us/api/?key='+adfocus_apikeys[i]+'&url='+await getHastebin())).data;
                if(url!="0"){
                    urls[urls.length] = url;
                }else{
                    console.log(`Invalid Api Key [${i+1}]`);
                }
            }
            torepeat_url = urls;
        }
        console.log("Urls: "+urls.join(" "));
        await filterProxies({checkInstances:()=>{return instances},onWorking:async proxy=>{
            while(instances>max_instances-1){await wait(1000)};
            if(slowdown!=0)await wait(slowdown);
            instances++;
            for(var x = 0;x<5;x++){
                for(var i = 0;i<urls.length;i++){
                    var instance = {start:Date.now()};
                    visit(urls[i],proxy,instance).then(result=>{console.log(`Finished with value [${result[0]}] and reason [${result[1]}]`)});
                    await wait(1000);
                    while(Date.now()-instance.start<try_timeout&&!instance.hasFinished()){
                        await wait(1000);
                    }
                    if(!instance.hasFinished()&&Date.now()-instance.start>try_timeout){
                        instance.cancel();console.log("Try timeout. Aborting instance...")
                    }
                }
            }
            instances--;
    }});
    await wait(5000);
    console.log("Saved "+saved_requests+" requests with size "+(saved_size/1000000)+"MB");
    for(var i = 0;i<Browsers.length;i++){
        try{Browsers[i].close()}catch(e){}
    }
    Browsers = [];
    }
})();